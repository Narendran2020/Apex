import { MatngularPage } from './app.po';

describe('matngular App', () => {
  let page: MatngularPage;

  beforeEach(() => {
    page = new MatngularPage();
  });

  it('should expect true to be true', () => {
    expect(true).toBe(true);
  });
});
