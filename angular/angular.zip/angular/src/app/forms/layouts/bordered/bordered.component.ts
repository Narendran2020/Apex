import { Component } from '@angular/core';

@Component({
  selector: 'app-bordered',
  templateUrl: './bordered.component.html',
  styleUrls: ['./bordered.component.scss']
})
export class BorderedComponent {
}
